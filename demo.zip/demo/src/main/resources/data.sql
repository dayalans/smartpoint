

create table employee (employeeid bigint not null, employeename varchar(50), employeesalary bigint not null, primary key (employeeid));

insert into employee (employeeid, employeename, employeesalary) values (1, 'dayalan', 25000);
insert into employee (employeeid, employeename, employeesalary) values (2, 'subramaniam', 35000);
insert into employee (employeeid, employeename, employeesalary) values (3, 'dinesh', 15000);
insert into employee (employeeid, employeename, employeesalary) values (4, 'Ram', 11000);
insert into employee (employeeid, employeename, employeesalary) values (5, 'Harish', 55000);